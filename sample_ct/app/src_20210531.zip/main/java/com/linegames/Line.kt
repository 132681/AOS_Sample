﻿package com.linegames;

import com.linegames.base.NTBase

import com.linecorp.linesdk.api.LineApiClient
import com.linecorp.linesdk.api.LineApiClientBuilder
import com.linecorp.linesdk.auth.LineAuthenticationParams
import com.linecorp.linesdk.auth.LineLoginApi
import com.linecorp.linesdk.LineApiResponseCode
import com.linecorp.linesdk.Scope

import android.support.v4.app.ActivityCompat
import android.content.Intent
import android.util.Log

import java.util.*
import org.json.JSONObject

class Line
{
    companion object
    {
        val TAG = "NTSDK"
        val LINE_LOGIN_REQUEST_CODE = 0x0FF
        var LOGIN_CB = 0;
        var LINE_CHANNEL_ID = "";

        enum class Status
        {
            SUCCESS,
            UNKNOWN,
            CANCEL,
            SERVER_ERROR,
            NETWORK_ERROR,
        }

        @JvmStatic val getInstance = Line()

        val lineApiClient : LineApiClient by lazy()
        {

            Log.d(TAG, "======================Line API =====================================")
            val apiClientBuilder = LineApiClientBuilder(NTBase.MainActivity, LINE_CHANNEL_ID)
            apiClientBuilder.build()
        }

        @JvmStatic fun Init( userCB: Long )
        {
            nativeCB(Status.SUCCESS.name, JSONObject().apply {
                put("Message", "Line Init Success")
            }.toString(), userCB)
        }

        @JvmStatic fun Login( channel_ID:String, userCB: Long )
        {
            if ( channel_ID.isNullOrEmpty() )
            {
                Log.d(TAG, "Channel_ID is null.")
                nativeCB(Status.UNKNOWN.name, JSONObject().apply {
                    put("Message", "Channel_ID is null. Check the ChannelID in ProjectSetting.")
                }.toString(), userCB)
            }

            LINE_CHANNEL_ID = channel_ID
            LOGIN_CB = userCB.toInt();

            Log.d(TAG, "Line.kt Login LineChannel : " + LINE_CHANNEL_ID)

            getInstance.LineLogin{ status: Status, msg: String ->
                nativeCB( status.name, msg, userCB )
            }
        }

        @JvmStatic fun Logout()
        {
            Log.d(TAG, "Line.kt Logout ")
            getInstance.LineLogout{ status: Status, msg: String ->
                nativeCB( status.name, msg, 0 )
            }
        }

        @JvmStatic fun Refresh( userCB: Long )
        {
            Log.d(TAG, "Line.kt Refresh ")
            getInstance.LineRefresh{ status: Status, msg: String ->
                nativeCB( status.name, msg, userCB )
            }
        }

        @JvmStatic fun Verify( userCB: Long )
        {
            Log.d(TAG, "Line.kt Verify ")
            getInstance.LineVerify{ status: Status, msg: String ->
                nativeCB( status.name, msg, userCB )
            }
        }

        @JvmStatic fun Profile( userCB: Long )
        {
            Log.d(TAG, "Line.kt Profile ")
            getInstance.LineProfile{ status: Status, msg: String ->
                nativeCB( status.name, msg, userCB )
            }
        }
        @JvmStatic private external fun nativeCB( status:String, msg:String, userCB:Long )
    }

    fun LineOnActivityResult( requestCode:Int, resultCode:Int, data:Intent? )
    {
        Log.d(TAG, "LineOnActivityResult "+ " requestCode : " + requestCode + " resultCode : " + resultCode)
        if( requestCode == 0x0FF )
        {
            val result = LineLoginApi.getLoginResultFromIntent(data)
            when ( result.responseCode ) {
                LineApiResponseCode.SUCCESS ->
                {   // Login successful
                    Log.d(TAG, "result : " + result.toString())
                    nativeCB(Status.SUCCESS.name,
                            JSONObject().apply {
                                put("userID", result.lineProfile!!.userId )
                                put("Message", "LineLogin Success!")
                                put("accessToken", result.lineCredential!!.accessToken.tokenString)
                            }.toString(),
                            LOGIN_CB.toLong())
                }

                LineApiResponseCode.CANCEL ->
                {   // Login canceled by user
                    Log.d("NTSDK", "LineLogin Canceled by user. " + result.errorData.toString())
                    nativeCB(Status.CANCEL.name,
                            JSONObject().apply { put("Message", "LineLogin Canceled by user.") }.toString(),
                            LOGIN_CB.toLong())
                }

                LineApiResponseCode.NETWORK_ERROR ->
                {   // Login canceled by user
                    Log.d("NTSDK", "LineLogin NETWORK_ERROR. " + result.errorData.toString())
                    nativeCB(Status.NETWORK_ERROR.name,
                            JSONObject().apply { put("Message", "LineLogin NETWORK_ERROR.") }.toString(),
                            LOGIN_CB.toLong())
                }

                LineApiResponseCode.SERVER_ERROR ->
                {   // Login canceled by user
                    Log.d("NTSDK", "LINE Login SERVER_ERROR. " + result.errorData.toString())
                    nativeCB(Status.SERVER_ERROR.name,
                            JSONObject().apply { put("Message", "LINE Login SERVER_ERROR.") }.toString(),
                            LOGIN_CB.toLong())
                }

                else ->
                {   // Login canceled due to other error
                    Log.e("NTSDK", "Login FAILED! " + result.errorData.toString())
                    nativeCB(Status.UNKNOWN.name,
                            JSONObject().apply { put("Message", result.errorData.toString()) }.toString(),
                            LOGIN_CB.toLong())

                }
            }
        }
    }

    private fun LineLogin( onResult: (Status,String) -> Unit )
    {
        if ( IsInValidParameter( onResult )) return;
        Thread(Runnable {
            lineApiClient.verifyToken().let { verify ->
                if ( verify.isSuccess )
                {
                    Log.d(TAG, "LineLogin Success. responseData : " + verify.responseData.toString())
                    onResult( Status.SUCCESS, JSONObject().apply {
                        put ("userID", lineApiClient.profile.responseData.userId)
                        put ("accessToken", lineApiClient.currentAccessToken.responseData.tokenString)
                        put ("displayName", lineApiClient.profile.responseData.displayName)
                        put ("pictureUrl", lineApiClient.profile.responseData.pictureUrl)
                        put ("statusMessage", lineApiClient.profile.responseData.statusMessage)
                        put ("Message", "LineLogin Success!!!")
                    }.toString())
                }
                else
                {
                    @SuppressWarnings("null")
                    if ( lineApiClient.currentAccessToken == null )
                    {
                        Log.d(TAG, "lineApiClient.currentAccessToken == null ")
                    }
                    else
                    {
                        Log.d(TAG, "lineApiClient.currentAccessToken != Not null !!!!!!")
                    }

                    Log.d(TAG, "verify errorData " + verify.errorData.message)

                    Log.d(TAG, "verify responseCode(" + verify.responseCode)
                    if (verify == null)
                    {
                        Log.d(TAG, "verify is null")
                    }
                    else
                    {
                        Log.d(TAG, "verify is Not null")
                    }
                    Log.d(TAG, "verify responseData(" + verify.responseData)

                    if (verify.responseData != null) //verify.reponseData가 있으면 Refresh
                     {
                         Log.d(TAG, "verify.responseData != null !!!!!!")
                     }
                     else
                     {
                         Log.d(TAG, "verify.responseData == null !!!!!!")
                     }

                    try
                    {
                        if (verify.responseData != null) //verify.reponseData가 있으면 Refresh
                        {
                            Line_AccessToken_Refresh(onResult)
                        }
                    } catch (e: Exception)
                    {
                        FirstLogin(onResult)  //verify.reponseData 가없으면 FirstLogin
                    }
                }
            }
        }).start()
    }

    fun FirstLogin( onResult: (Status,String) -> Unit )
    {
        Log.d(TAG, "FirstLogin LINE_CHANNEL_ID : " + LINE_CHANNEL_ID)
        if ( IsInValidParameter( onResult )) return;
        Thread(Runnable {
            try {
                val loginIntent = LineLoginApi.getLoginIntent(
                        NTBase.MainActivity,
                        LINE_CHANNEL_ID,
                        LineAuthenticationParams.Builder()
                                .scopes(Arrays.asList(Scope.PROFILE))
                                .build())
                ActivityCompat.startActivityForResult(NTBase.MainActivity, loginIntent, LINE_LOGIN_REQUEST_CODE, null)
            } catch ( e: Exception ) {
                Log.e(TAG, "FirstLogin Exception error: " + e.toString())
                onResult( Status.UNKNOWN,
                        JSONObject().apply { put("Message", e.toString()) }.toString())
            }
        }).start()
    }

    private fun LineLogout( onResult: (Status,String) -> Unit )
    {
        if ( IsInValidParameter( onResult ) ) return;

        Thread(Runnable {
            try {
                lineApiClient.logout().run {
                    if (isSuccess)
                    {
                        Log.d(TAG, "LineLogout Success!")
                    }
                    else
                    {
                        Log.d(TAG, "LineLogout Fail erroData : " + errorData.toString())
                    }
                }
            } catch (e: Exception){
                Log.e(TAG, "LineLogout Exception error : " + e.toString())
            }
        }).start()
    }

    private fun LineRefresh( onResult: (Status,String) -> Unit )
    {
        Line_AccessToken_Refresh( onResult )
    }

    private fun Line_AccessToken_Refresh( onResult: (Status,String) -> Unit )
    {
        if ( IsInValidParameter( onResult )) return;
        Thread(Runnable {
            try
            {
                lineApiClient.refreshAccessToken().let { refresh ->
                    if ( refresh.isSuccess )
                    {
                        Log.d(TAG, "LineRefresh Success!")
                        onResult( Status.SUCCESS, JSONObject().apply {
                            put ("userID", lineApiClient.profile.responseData.userId)
                            put ("accessToken", refresh.responseData.tokenString)
                            put ("displayName", lineApiClient.profile.responseData.displayName)
                            put ("pictureUrl", lineApiClient.profile.responseData.pictureUrl)
                            put ("statusMessage", lineApiClient.profile.responseData.statusMessage)
                            put ("Message", "Silent LineLogin Success!!")
                        }.toString())
                    }
                    else
                    {
                        Log.d(TAG, "LineRefresh Fail UnknownError : " + refresh.responseData.toString())
                        Log.d(TAG, "LineRefresh Fail message  : " + refresh.errorData.message)
                        onResult( Status.UNKNOWN,
                                JSONObject().apply { put("Message", refresh.responseData.toString()) }.toString())
                    }
                }
            } catch ( e : Exception )
            {
                Log.d(TAG, "LineRefresh Exception Error : " + e.toString())
                onResult( Status.UNKNOWN,
                        JSONObject().apply { put("Message", e.toString()) }.toString())
            }
        }).start()
    }

    private fun LineVerify( onResult: (Status,String) -> Unit )
    {
        Log.d(TAG, "LineVerify ")
        Thread(Runnable {
            try
            {
                lineApiClient.verifyToken().let { verify ->
                    if ( verify.isSuccess )
                    {
                        Log.d(TAG, "LineVerify Success. responseData : " + verify.responseData.toString())
                        onResult( Status.SUCCESS, JSONObject().apply {
                            put ("userID", GetLineUserID() )
                            put ("accessToken", verify.responseData.accessToken.tokenString)
                            put ("displayName", lineApiClient.profile.responseData.displayName)
                            put ("pictureUrl", lineApiClient.profile.responseData.pictureUrl)
                            put ("statusMessage", lineApiClient.profile.responseData.statusMessage)
                            put ("Message", "Silent LineLogin Success!")
                        }.toString())
                    }
                    else
                    {
                        Log.d(TAG, "LineVerify Fail. errorData : " + verify.errorData.toString())
                        onResult(Status.UNKNOWN,
                                JSONObject().apply { put("Message", verify.errorData.toString()) }.toString())
                    }
                }
            } catch (e: Exception)
            {
                Log.d(TAG, "LineVerify Exception Error : " + e.toString())
                onResult( Status.UNKNOWN,
                        JSONObject().apply { put("Message", e.toString()) }.toString())
            }
        }).start()
    }

    private fun LineProfile( onResult: (Status,String) -> Unit )
    {
        Log.d(TAG, "LineProfile ")
        if ( IsInValidParameter( onResult )) return;

        Thread(Runnable {
            try
            {
                lineApiClient.profile.apply {
                    if ( isSuccess )
                    {
                        val profile = responseData
                        Log.d(TAG, "LineProfile Success")
                        Log.d(TAG, "LineProfile responseCode : " + responseCode)
                        Log.d(TAG, "LineProfile displayName : " + profile.displayName)
                        Log.d(TAG, "LineProfile picuturUrl : " + profile.pictureUrl)
                        Log.d(TAG, "LineProfile statusMessage : " + profile.statusMessage)
                        Log.d(TAG, "LineProfile userID : " + profile.userId)
                        onResult( Status.SUCCESS,
                                JSONObject().apply
                                {
                                    put("DisplayName", profile.displayName)
                                    put("PictureUrl", profile.pictureUrl)
                                    put("StatusMessage", profile.statusMessage)
                                    put("userID", profile.userId)
                                    put("Message", "LINE Profile Success")
                                    put("responseCode", responseCode)
                                }.toString() )
                    }
                    else
                    {
                        Log.d(TAG, "LineProfile Fail responseCode : " + responseCode)
                        onResult( Status.UNKNOWN,
                                JSONObject().apply { put("Message","Line Profile Fail.") }.toString())
                    }

                }
            } catch (e: Exception)
            {
                Log.d(TAG, "LineProfile Exception Error : " + e.toString())
                onResult( Status.UNKNOWN,
                        JSONObject().apply { put("Message", e.toString()) }.toString())
            }
        }).start()
    }

    fun IsInValidParameter( onResult: (Status,String) -> Unit ): Boolean
    {
        if ( LINE_CHANNEL_ID.isNullOrEmpty())
        {
            Log.e(TAG, "")
            onResult( Status.UNKNOWN,
                    JSONObject().apply { put("Message","Please Login First.") }.toString())
            return true;
        }
        return false;
    }

    fun GetLineUserID() : String?
    {
        if ( LINE_CHANNEL_ID.isNullOrEmpty())
        {
            Log.e(TAG, "GetLineUserID() is null. Check the ChannelID in ProjectSetting.")
            return null
        }

        try {
            return lineApiClient.profile.responseData.userId
        } catch (e: Exception)
        {
            Log.e(TAG, "GetLineUserID() Exception error : "+ e.toString())
            return null
        }
    }
}