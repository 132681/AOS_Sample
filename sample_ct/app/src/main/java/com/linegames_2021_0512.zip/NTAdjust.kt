package com.linegames;

import android.app.Activity
import android.app.Application
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import com.adjust.sdk.Adjust
import com.adjust.sdk.AdjustConfig
import com.adjust.sdk.LogLevel
import com.adjust.sdk.AdjustEvent
import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.linegames.base.NTBase
import android.R.attr.gravity
import android.text.TextUtils
import android.widget.Toast
import com.adjust.sdk.OnDeviceIdsRead

class NTAdjust
{
    var GPS_ADID: String? = null

    public constructor()
    {
        generationAdId();
    }

    companion object
    {
        private const val TAG = "NTSDK"
        val instance = NTAdjust()

        @JvmStatic external fun InitReciever( sAdid : String?, AdjustAdid : String? )
        @JvmStatic fun Init( sAppToken :String, sTrackerToken :String?, sEnvironment :String , sSecreteId :Long , sInfo1 :Long , sInfo2 :Long , sInfo3 :Long , sInfo4 :Long )
        {
            instance.AdjustInit(sAppToken, sTrackerToken,  sEnvironment , sSecreteId, sInfo1, sInfo2, sInfo3, sInfo4)
        }

        @JvmStatic fun TrackEvent( sEventToken : String, sNid : String, sGNid : String, sGameServerID : String, sOrderId : String?, sCurrencyType : String?, Amount : Double )
        {
            instance.AdjustTrackEvent(sEventToken, sNid, sGNid, sGameServerID, sOrderId, sCurrencyType, Amount)
        }

        @JvmStatic fun GetAdjustAdid() : String?
        {
            return instance.GetAdjust_Adid()
        }

        @JvmStatic fun GetAdid() : String?
        {
            return instance.GetGPSAdid()
        }

        @JvmStatic fun IsInitAdjust() : Boolean
        {
            return instance.IsInit_Adjust()
        }
    }

    fun AdjustInit(appToken: String, sTrackerToken: String?, environment: String, secretId: Long, info1: Long, info2: Long, info3: Long, info4: Long)
    {
        Log.d(TAG, "============================== AdjustSdkVersion() : " + Adjust.getSdkVersion())
        Log.d(TAG, "============================== AdjustInit appToken : " + appToken + " sTrackerToken : " + sTrackerToken + " environment : " + environment + " secretId : " + secretId+ " info1 : " + info1+ " info2 : " + info2+ " info3 : " + info3+ "info4 : " + info4)

        val setAdjustLogOFF : Boolean = false

        val config = AdjustConfig(NTBase.MainActivity, appToken, environment, setAdjustLogOFF)

        if (!sTrackerToken.isNullOrEmpty())
            config.setDefaultTracker(sTrackerToken)

        if(setAdjustLogOFF){
            config.setLogLevel(LogLevel.SUPRESS)//log off
        } else {
            config.setLogLevel(LogLevel.VERBOSE)//log on
        }

        config.setOnAttributionChangedListener {
            Log.d(TAG, "---------------- Attribution callback called! ---------------- : " + it.adid)
        }

        // Set session success tracking delegate.
        config.setOnSessionTrackingSucceededListener { sessionSuccessResponseData ->
            Log.d(TAG, "Session success callback called!")
            Log.d(TAG, "Session success data: $sessionSuccessResponseData")
            Log.d(TAG, "---------------- sessionSuccessResponseData.adid ---------------- : " + sessionSuccessResponseData.adid)
            Log.d(TAG, "---------------- GPS_ADID ---------------- : " + GPS_ADID)
            InitReciever( GPS_ADID, sessionSuccessResponseData.adid )
        }

        // Set session failure tracking delegate.
        config.setOnSessionTrackingFailedListener {
            Log.d(TAG, "---------------- Session failure callback called! ---------------- : " + it.adid)
        }
        // Allow to send in the background.
        config.setSendInBackground(true)

        Adjust.onCreate(config)

        AdjustLifecycleCallbacks()

        Adjust.onResume()
    }

    fun AdjustTrackEvent(sEventToken : String, sNid : String, sGNid : String, sGameServerID : String, sOrderID : String?, sCurrencyType : String?, sAmount : Double)
    {
        Log.d( TAG, "NTAdjust.kt AdjustTrackEvent eventToken : " + sEventToken + " sNid : " + sNid+ " sGNid : " + sGNid  + " sGameServerID : " + sGameServerID + " sOrderID : " + sOrderID  + " sCurrencyType : " + sCurrencyType  + " sAmount : " + sAmount )

        val event = AdjustEvent(sEventToken)
        if(!TextUtils.isEmpty(sNid)) event.setCallbackId(sNid)
        if(!TextUtils.isEmpty(sGNid)) event.addCallbackParameter("gnid", sGNid )
        if(!TextUtils.isEmpty(sGNid)) event.addPartnerParameter("gnid", sGNid )
        if(!TextUtils.isEmpty(sGameServerID)) event.addCallbackParameter("server_id", sGameServerID )
        if(!TextUtils.isEmpty(sGameServerID)) event.addPartnerParameter("server_id", sGameServerID )
        if(!TextUtils.isEmpty(sOrderID)) event.setOrderId(sOrderID)
        if(!TextUtils.isEmpty(sCurrencyType)) event.setRevenue(sAmount, sCurrencyType)
        Adjust.trackEvent(event)
    }

    /** Retrieve the Android Advertising Id
     *
     * The device must be KitKat (4.4)+
     * This method must be invoked from a background thread.
     *
     */
    @Synchronized
    fun generationAdId()
    {
        AsyncTask.execute {
            try {
                GPS_ADID = AdvertisingIdClient.getAdvertisingIdInfo(NTBase.MainActivity.getApplicationContext()).id
                Log.d(TAG, "---------------- generationAdId GPS_ADID ---------------- : " + GPS_ADID)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun GetGPSAdid() : String?
    {
        Log.d(TAG, "GetGPSAdid GPS_ADID : " + GPS_ADID)
        return GPS_ADID
    }

    fun GetAdjust_Adid() : String?
    {
        var AdjustAdid = Adjust.getAdid()
        Log.d(TAG, "NTAdjust.kt GetAdjust_Adid : " + AdjustAdid)
        return AdjustAdid
    }

    fun IsInit_Adjust() : Boolean
    {
        if (GetAdjust_Adid() == null)
            return false;
        else
            return true;
    }

    fun SetOfflineMode(offLineModeEnable : Boolean)
    {
        Log.d(TAG, "SetOfflineMode : " + offLineModeEnable)
        Adjust.setOfflineMode(offLineModeEnable)
    }

    fun SetEnableDisableSDK(enableDisableSDK : Boolean)
    {
        Log.d(TAG, "SetEnableDisableSDK : " + enableDisableSDK)
        Adjust.setEnabled(enableDisableSDK)
    }

    // You can use this class if your app is for Android 4.0 or higher
    private class AdjustLifecycleCallbacks : Application.ActivityLifecycleCallbacks
    {
        override fun onActivityResumed(activity: Activity) { Adjust.onResume() }
        override fun onActivityPaused(activity: Activity) { Adjust.onPause() }
        override fun onActivityStopped(activity: Activity) {}
        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
        override fun onActivityDestroyed(activity: Activity) {}
        override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle) {}
        override fun onActivityStarted(activity: Activity) {}
    }

}