package com.linegames;

import android.app.Activity;
import android.support.annotation.Nullable;
import android.util.Log;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.PurchaseHistoryRecord;
import com.android.billingclient.api.PurchaseHistoryResponseListener;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.linegames.base.NTBase;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class Purchase implements PurchasesUpdatedListener
{
    private static String LOG_TAG = "NTSDK";
    private static String PURCHASE_TAG = "PurchaeAPI";

    private static String result_msg= "Connect Success.";
    private static String result_status = "NT_SUCCESS";
    private static int result_ResponseCode = 0;
    private static long purchaseCB = 0L;
    private static long noCB = 777;

    private static Activity mMainActivity;
    private static BillingClient mBillingClient;
    private static ArrayList<String> productIdArr;
    private static List<SkuDetails> mSkuDetailsList;
    private static List<com.android.billingclient.api.Purchase> mPurchases;
    private static HashMap<String, SkuDetails> mSkuDetailsListMap;

    private static Purchase getInstance = null;
    public native void nativeCB( String status, String msg, long userCB );

    public static synchronized Purchase GetInstance() {
        if (getInstance == null) {
            synchronized ( Purchase.class ) {
                if ( getInstance == null )
                    getInstance = new Purchase();
            }
        }
        return getInstance;
    }

    public static void Connect( final long userCB )
    {
        Debug( "Connect() userCB :" + userCB );

        result_status = "UNKNOWN";
        result_ResponseCode = -1;

        if ( IsConnected() ) {
            result_msg = "PurchaseAPI Already connected.";
            DebugError(result_msg);
            result_status = "NT_SUCCESS";
            result_ResponseCode = 0;
            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
            return;
        }

        mMainActivity = NTBase.getMainActivity();
        mMainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                final JSONObject jsonResult = new JSONObject();

                mBillingClient = BillingClient.newBuilder(mMainActivity)
                        .enablePendingPurchases()
                        .setListener(Purchase.GetInstance())
                        .build();

                mBillingClient.startConnection(new BillingClientStateListener() {
                    @Override
                    public void onBillingSetupFinished(BillingResult billingResult) {

                        result_msg = billingResult.getDebugMessage();
                        if ( billingResult.getResponseCode() ==  BillingClient.BillingResponseCode.OK )
                        if ( billingResult.getResponseCode() ==  BillingClient.BillingResponseCode.OK )
                        {
                            // The BillingClient is ready. You can query purchases here.
                            result_status = "NT_SUCCESS";
                            result_msg = "Connect Success.";
                        }
                        else
                        {
                            result_status = "UNKNOWN";
                            if ( billingResult.getResponseCode() == 3 )
                                result_status = "NE_PURCHASE_UPDATE_GOOGLEPLAY";
                        }

                        try {
                            jsonResult.put( "Message", billingResult.getDebugMessage() );
                            jsonResult.put( "ResponseCode", billingResult.getResponseCode() );
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        GetInstance().Invoke( result_status, new JSONArray(), result_msg, billingResult.getResponseCode() , userCB );
                    }
                    @Override
                    public void onBillingServiceDisconnected() {
                        // Try to restart the connection on the next request to
                        // Google Play by calling the startConnection() method.
                        try {
                            jsonResult.put( "Message", "Purchase DisConnected." );
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        GetInstance().Invoke( "UNKNOWN", new JSONArray(), "Purchase DisConnected.", -1 , userCB );
                    }
                });
            }
        });
    }

    private void DisConnect()
    {
        if ( IsConnected() )
        {
            mBillingClient.endConnection();
            mBillingClient = null;
            Debug( "Connection DisConnect" );
        }
    }

    public static void RegisterProduct( String jProductID )
    {
        if (jProductID.isEmpty())
        {
            DebugError("RegisterProduct pID is null");
            return;
        }

        if (productIdArr == null)
            productIdArr = new ArrayList<>();

        if (productIdArr.contains(jProductID))
            return;

        GetInstance().productIdArr.add(jProductID);
        Debug( "RegisterProduct pID : " +jProductID );
    }

    public static void RefreshProductInfo( final long userCB )
    {
        if ( !CheckInitlized( userCB ) ) return;

        final int inputProductsCount = productIdArr.size();
        final int defaultCount = 20;

        Debug( "RefreshProductInfo() Input ProductId : " + productIdArr.toString());

        final JSONArray productsJsonArray = new JSONArray();
        mSkuDetailsList = new ArrayList<SkuDetails>();
        final ArrayList<String> invalidProductsId = productIdArr;
        final int[] queryCompleteCounter = new int[] { 0 };
        final int loopCnt = inputProductsCount / defaultCount;

        mMainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                for(int i = 0 ; i < loopCnt + 1; i++)
                {
                    List<String> productsInfo = productIdArr.subList( i * defaultCount , Math.min(inputProductsCount, ( i + 1 ) * defaultCount) );
                    SkuDetailsParams.Builder params = SkuDetailsParams.newBuilder();
                    params.setSkusList(productsInfo).setType(BillingClient.SkuType.INAPP);
                    int endcnt = i;
                    mSkuDetailsListMap = new HashMap<String, SkuDetails>();
                    mBillingClient.querySkuDetailsAsync( params.build(), new SkuDetailsResponseListener()
                    {
                        @Override
                        public void onSkuDetailsResponse(BillingResult billingResult,
                                                         List<SkuDetails> skuDetailsList)
                        {
                            if ( billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK )
                            {
                                mSkuDetailsList.addAll(skuDetailsList);
                                try {
                                    for (SkuDetails product : skuDetailsList) {
                                        mSkuDetailsListMap.put( product.getSku(), product );
                                        long microsPrice = product.getPriceAmountMicros();
                                        Debug( "long microsPrice : " + microsPrice);
                                        double dMicroPrice = (double)microsPrice;
                                        Debug( "double dMicroPrice : " + dMicroPrice);
                                        productsJsonArray.put(new JSONObject()
                                                .put("productId", product.getSku())
                                                .put("title", product.getTitle())
                                                .put("description", product.getDescription())
                                                .put("price", product.getPrice())
                                                .put("microPrice", Long.toString(product.getPriceAmountMicros()))
                                                .put("currencyCode", product.getPriceCurrencyCode())
                                        );

                                        if ( invalidProductsId.contains( product.getSku() ) )
                                        {
                                            invalidProductsId.remove( product.getSku() );
                                        }
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                    DebugError(e.getMessage());
                                }
                            }
                            String resultMsg;
                            int resultCode;

                            synchronized (queryCompleteCounter)
                            {
                                resultCode = billingResult.getResponseCode();
                                if ( queryCompleteCounter[0] == loopCnt )
                                {
                                    resultMsg = "Success. productsId Count : " + productsJsonArray.length();
                                    if ( productsJsonArray.length() != inputProductsCount )
                                    {
                                        if (resultCode == 2)
                                            resultMsg = billingResult.getDebugMessage();
                                        else
                                            resultMsg = "Invalid ProductID List => " + invalidProductsId.toString();
                                    }
                                    else
                                    {
                                        result_status = "NT_SUCCESS";
                                        resultCode = 0;
                                    }

                                    GetInstance().Invoke( result_status, productsJsonArray, resultMsg, resultCode , userCB );
                                }
                                queryCompleteCounter[0]++;
                            }
                        }
                    });
                }
            }
        });
    }

    public static void BuyProduct( String jProductID, String jDeveloperPayload, long lUserCB )
    {

        Debug("BuyProduct productID : " + jProductID + " DeveloperPayload : " + jDeveloperPayload );
        final String productID = jProductID;
        final String developerPayload = jDeveloperPayload;
        final long userCB = lUserCB;

        if ( !CheckInitlized( userCB ) ) return;

        final JSONArray productsJsonArray = new JSONArray();

        if ( productID.isEmpty() ) {
            result_msg = "BuyProduct() productID is null.";
            DebugError(result_msg);
            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
            return;
        }
        purchaseCB = userCB;
        mMainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                SkuDetails buyProductSkuDetail = null;
                if ( mSkuDetailsList != null )
                {
                    for ( SkuDetails detail : mSkuDetailsList )
                    {
                        if ( detail.getSku().equals(productID) )
                        {
                            Debug("find productID SkuDetail : " + productID);
                            buyProductSkuDetail = detail;
                            break;
                        }
                    }

                    if ( buyProductSkuDetail == null )
                    {
                        result_msg = "ProductID does no match. Please Check productID ( " + productID + " ) ";
                        DebugError(result_msg);
                        GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
                        return;
                    }

                    BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                            .setSkuDetails(buyProductSkuDetail)
                            .setObfuscatedAccountId( developerPayload )
                            .build();

                    mBillingClient.launchBillingFlow(mMainActivity, flowParams);
                    return;
                }
                else
                {
                    result_msg = "Purchase is not ready. Call RefreshProductInfo() API.";
                    DebugError(result_msg);
                }

                GetInstance().Invoke( result_status, productsJsonArray, result_msg, result_ResponseCode , userCB );
            }
        });
    }

    @Override
    public void onPurchasesUpdated(BillingResult billingResult, @Nullable List<com.android.billingclient.api.Purchase> purchases)
    {
        result_status = "UNKNOWN";
        result_msg = billingResult.getDebugMessage();

        int responseCode = billingResult.getResponseCode();
        final JSONArray productsJsonArray = new JSONArray();

        Debug("onPurchasesUpdated: $responseCode $debugMessage responseCode " + responseCode);
        switch (responseCode) {
            case BillingClient.BillingResponseCode.OK:
                if (purchases == null) {
                    Debug( "onPurchasesUpdated: null purchase list");
                }
                else
                {
                    mPurchases = purchases;
                    try {
                        for (com.android.billingclient.api.Purchase product : mPurchases)
                        {
                            productsJsonArray.put(new JSONObject()
                                    .put("productId", product.getSku() )
                                    .put("microPrice", mSkuDetailsListMap.get( product.getSku() ).getPriceAmountMicros() )
                                    .put("currencyCode", mSkuDetailsListMap.get( product.getSku() ).getPriceCurrencyCode() )
                                    .put("originalJson", product.getOriginalJson() )
                                    .put("developerPayload", product.getDeveloperPayload() )
                                    .put("signature", product.getSignature() )
                            );
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        result_msg = e.getMessage();
                    }
                }
                result_status = "NT_SUCCESS";
                GetInstance().Invoke( result_status, productsJsonArray, billingResult.getDebugMessage(), billingResult.getResponseCode() , purchaseCB );
                return;
            case BillingClient.BillingResponseCode.USER_CANCELED:
                result_msg = "onPurchasesUpdated: User canceled the purchase.";
                result_status = "USER_CANCELED";
                DebugError(result_msg);
                break;
            case BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED:
                result_status = "ITEM_ALREADY_OWNED";
                result_msg = "onPurchasesUpdated: The user already owns this item";
                DebugError(result_msg);
                //Need Consume Process
                break;
            case BillingClient.BillingResponseCode.DEVELOPER_ERROR:
                result_msg = "onPurchasesUpdated: Developer error means that Google Play " +
                        "does not recognize the configuration. If you are just getting started, " +
                        "make sure you have configured the application correctly in the " +
                        "Google Play Console. The SKU product ID must match and the APK you " +
                        "are using must be signed with release keys.";
                DebugError(result_msg);
                break;
            case BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE:
                result_msg = "onPurchasesUpdated: Need Goolge Account Login!!!";
                DebugError(result_msg);
                //Need Google Account login
                break;
            case BillingClient.BillingResponseCode.ITEM_UNAVAILABLE:
                result_msg = "Need Test URL confirm.";
                DebugError(result_msg);
                //Need Test URL confrim
                break;
            case BillingClient.BillingResponseCode.ERROR:
                result_msg = "This card cannot be paid.";
                result_status = "CREDITCARD_UNAVAILABLE";
                DebugError(result_msg);
                //This creditcard cannot be paid.
                break;
        }
        GetInstance().Invoke( result_status, productsJsonArray, result_msg, billingResult.getResponseCode() , purchaseCB );
    }

    public static void Consume( final String productID, final long userCB )
    {
        Debug( " Consume() productID : " + productID );
        if ( !CheckInitlized( userCB ) ) return;

        if ( productID.isEmpty() )
        {
            result_msg = " Consume() productID is NULL.";
            DebugError(result_msg);
            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
        }
        else
        {
            if ( mPurchases != null )
            {
                ConsumeParams consumeParams = null;
                for (com.android.billingclient.api.Purchase purchaseData : mPurchases )
                {
                    if ( productID.equals(purchaseData.getSku()) )
                    {
                        consumeParams = ConsumeParams.newBuilder()
                                .setPurchaseToken(purchaseData.getPurchaseToken())
                                .build();
                        Debug( " Consume() consumeParams productID : " + purchaseData.getSku() );
                        break;
                    }
                }

                if ( consumeParams != null )
                {
                    final JSONArray productsJsonArray = new JSONArray();
                    mBillingClient.consumeAsync( consumeParams, new ConsumeResponseListener() {
                        @Override
                        public void onConsumeResponse(BillingResult billingResult, String s)
                        {
                            if ( billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK )
                            {
                                result_status = "NT_SUCCESS";
                                result_ResponseCode = 0;
                                result_msg = " Consume Success ( " + productID + " )";
                                Debug( result_msg );
                            }
                            else
                            {
                                result_msg = productID + "Purchase.java Consume() fail ";
                                result_ResponseCode = billingResult.getResponseCode();
                                DebugError( result_msg );
                            }
                            GetInstance().Invoke( result_status, productsJsonArray , result_msg, result_ResponseCode , userCB );
                        }
                    });
                }
                else
                {
                    result_msg = productID + " Consume() consumeParams is null. Check the productID ";
                    DebugError( result_msg );
                    GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
                }
            }
            else
            {
                result_msg = productID + " Consume() mPurchases is null.";
                DebugError( result_msg );
                GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
            }
        }
    }

    public static void RestoreProduct( long userCB )
    {
        Debug( "RestoreProduct() start" );

        if ( !CheckInitlized( userCB ) ) return;
        final JSONArray productsJsonArray = new JSONArray();
        int loopCnt = 0;

        com.android.billingclient.api.Purchase.PurchasesResult purchasesResult = mBillingClient.queryPurchases(BillingClient.SkuType.INAPP);
        Debug("RestoreProduct() Restore Item Count : " + Objects.requireNonNull(purchasesResult.getPurchasesList()).size() );

        if (mSkuDetailsListMap == null || mSkuDetailsListMap.size() < 1)
        {
            DebugError("RestoreProduct() mSkuDetailsListMap is null. ");
            GetInstance().Invoke( "UNKNOWN", productsJsonArray, "RestoreProduct is not ready. Call RefreshProductInfo() API.", -1 , userCB );
            return;
        }

        mPurchases = purchasesResult.getPurchasesList();

        for ( com.android.billingclient.api.Purchase PurchasesResult : purchasesResult.getPurchasesList() )
        {
            try {
                productsJsonArray.put(new JSONObject()
                        .put("originalJson", PurchasesResult.getOriginalJson() )
                        .put("microPrice", Objects.requireNonNull( mSkuDetailsListMap.get(PurchasesResult.getSku()), "mSkuDetailsListMap is null").getPriceAmountMicros() )
                        .put("currencyCode", Objects.requireNonNull( mSkuDetailsListMap.get(PurchasesResult.getSku()), "mSkuDetailsListMap is null").getPriceCurrencyCode() )
                        .put("signature", PurchasesResult.getSignature() )
                );
            }
            catch (Exception e)
            {
                e.printStackTrace();
                DebugError(result_msg);
            }
            loopCnt++;
        }

        if ( loopCnt == purchasesResult.getPurchasesList().size() )
        {
            String resultMsg;
            result_ResponseCode = purchasesResult.getResponseCode();
            if (productsJsonArray.length() < 1)
                resultMsg = "Restore Product does not Exist.";
            else
                resultMsg = purchasesResult.getBillingResult().getDebugMessage();

            GetInstance().Invoke( "NT_SUCCESS", productsJsonArray, resultMsg, result_ResponseCode , userCB );
        }
    }

    public static void ConsumeAll( long userCB )
    {
        Debug( "ConsumeAll()" );

        if ( !CheckInitlized( userCB ) ) return;
        com.android.billingclient.api.Purchase.PurchasesResult purchasesResult = mBillingClient.queryPurchases(BillingClient.SkuType.INAPP);

        if ( Objects.requireNonNull(purchasesResult.getPurchasesList()).size() < 1 )
        {
            Debug( " ConsumeAll() queryPurchases count is 0." );
        }
        else
        {
            ConsumeParams consumeParams;
            for (final com.android.billingclient.api.Purchase purchase : purchasesResult.getPurchasesList()) {
                consumeParams = ConsumeParams.newBuilder()
                        .setPurchaseToken(purchase.getPurchaseToken())
                        .build();

                mBillingClient.consumeAsync( consumeParams, new ConsumeResponseListener() {
                    @Override
                    public void onConsumeResponse(BillingResult billingResult, String s) {

                        if ( billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK )
                        {
                            Debug( purchase.getSku() + " Consume() Success. Consume s : " + s );
                        }
                        else
                        {
                            Debug( purchase.getSku() + " Consume() Fail. Consume s : " + s + "getResponseCode : " + billingResult.getResponseCode() );
                        }
                    }
                });
            }
        }
    }

    private void Invoke( String result_status, JSONArray productJsonArr, String msg, int resultCode, long userCB )
    {
        final JSONObject jsonResult = new JSONObject();
        try
        {
            jsonResult.put( "products", productJsonArr );
            jsonResult.put( "Message", msg );
            jsonResult.put( "ResponseCode", resultCode);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            result_msg = e.getMessage();
            DebugError(result_msg);
        }

        if (userCB != noCB)
        {
            Debug( "Invoke() status : " + result_status + " msg : " + jsonResult.toString() + " userCB : " + userCB  );
            nativeCB( result_status, jsonResult.toString(), userCB );
        }
    }

    private static boolean CheckInitlized( long userCB )
    {
        if ( mMainActivity == null )
            mMainActivity = NTBase.getMainActivity();

        result_status = "UNKNOWN";
        result_ResponseCode = -1;

        if ( !IsConnected() )
        {
            result_msg = "Purchase is not ready. First Call Connect() API.";
            DebugError(result_msg);
            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
            return false;
        }
        return true;
    }

    private static boolean IsConnected()
    {
        return mBillingClient != null && mBillingClient.isReady();
    }

    public void OnResume()
    {
        Debug("NTSDK OnResume");
        if ( mMainActivity != null )
        {
            Connect( noCB );
        }
    }

    public void OnStop()
    {
        Debug("NTSDK OnStop");
        DisConnect();
    }

    //=======================================//    Log    //========================================//
    private static void Debug( String logMessage )
    {
        GetInstance().LogLineDebug( "[" + PURCHASE_TAG + "]: " + logMessage );
    }

    private void LogLineDebug(String str) {

        int limitedline = 3000;
        String temp_json = str;
        int log_index = 1;
        try {
            while (temp_json.length() > 0) {

                if (temp_json.length() > limitedline) {
                    Log.d(LOG_TAG, "log - " + log_index + " : "
                            + temp_json.substring(0, limitedline));
                    temp_json = temp_json.substring(limitedline);
                    log_index++;
                } else {
                    Log.d(LOG_TAG, temp_json);
                    break;
                }
            }
        } catch (Exception e)
        {
            e.printStackTrace();
            DebugError(result_msg);
        }
    }

    private static void DebugError( String logMessage )
    {
        Log.e( LOG_TAG, "[" + PURCHASE_TAG + "]: " + logMessage );
    }
    //========================================//    Log    //=========================================//

    //    Not Use 2020/08/06 LSS    //
    public void GetPurchaseHistory()
    {
        Debug( "GetPurchaseHistory() start" );

        if ( !CheckInitlized( noCB ) ) return;

        mBillingClient.queryPurchaseHistoryAsync(BillingClient.SkuType.INAPP, new PurchaseHistoryResponseListener() {
            @Override
            public void onPurchaseHistoryResponse(BillingResult billingResult, List<PurchaseHistoryRecord> list) {

                for (PurchaseHistoryRecord historyPurchase : list)
                {
                    Debug("History purchase getOriginalJson : " + historyPurchase.getOriginalJson());
                    Debug("History purchase getSignature : " + historyPurchase.getSignature());
                }
            }
        });
    }
}