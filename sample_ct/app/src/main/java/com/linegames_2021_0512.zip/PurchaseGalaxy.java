package com.linegames;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.linegames.base.NTBase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import android.content.Intent;
import com.samsung.android.sdk.iap.lib.helper.HelperDefine.OperationMode;
import com.samsung.android.sdk.iap.lib.helper.IapHelper;
import com.samsung.android.sdk.iap.lib.listener.OnConsumePurchasedItemsListener;
import com.samsung.android.sdk.iap.lib.listener.OnGetOwnedListListener;
import com.samsung.android.sdk.iap.lib.listener.OnGetProductsDetailsListener;
import com.samsung.android.sdk.iap.lib.listener.OnPaymentListener;
import com.samsung.android.sdk.iap.lib.vo.ConsumeVo;
import com.samsung.android.sdk.iap.lib.vo.ErrorVo;
import com.samsung.android.sdk.iap.lib.vo.OwnedProductVo;
import com.samsung.android.sdk.iap.lib.vo.ProductVo;
import com.samsung.android.sdk.iap.lib.vo.PurchaseVo;

public class PurchaseGalaxy
{
    private static String LOG_TAG = "NTSDK";
    private static String PURCHASE_TAG = "PurchaseAPI";
    private static String result_msg= "Connect Success.";
    private static String result_status = "NT_SUCCESS";
    private static String PURCHASEID = "purchaseId";

    private static int result_ResponseCode = 0;
    private static long purchaseCB = 0L;
    private static long noCB = 777;
    private static long PURCHASE_GALAXY_REQUEST_CODE = 0x0FA;
    private static String mConsumedItemId = "";
    private static OperationMode IAP_MODE = OperationMode.OPERATION_MODE_TEST;

    private static IapHelper mIapHelper = null;
    private static Activity mMainActivity;
    private static ArrayList<String> productIdArr;
    private static JSONArray mProductsJsonArray;

    private static PurchaseGalaxy getInstance = null;
    public native void nativeCB( String status, String msg, long userCB );

    public static synchronized PurchaseGalaxy GetInstance() {
        if (getInstance == null) {
            synchronized ( PurchaseGalaxy.class ) {
                if ( getInstance == null )
                    getInstance = new PurchaseGalaxy();
            }
        }
        return getInstance;
    }

    public static void Connect( final long userCB )
    {
        Debug( "Connect() Galaxy userCB  (Galaxy) :" + userCB );

        mMainActivity = NTBase.getMainActivity();

        result_status = "NT_SUCCESS";
        result_ResponseCode = 0;

        if (mIapHelper  == null)
        {
            mIapHelper = IapHelper.getInstance( mMainActivity.getApplicationContext() );
            mIapHelper.setOperationMode(IAP_MODE);
            result_msg = "PurchaseAPI Init Success (Galaxy) ";
        }
        else
        {
            result_msg = "PurchaseAPI Already connected. (Galaxy) ";
            DebugError(result_msg);
            result_status = "NT_SUCCESS";
        }
        GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
    }

    private void DisConnect()
    {
        if ( IsConnected() )
            Debug( "Connection DisConnect (Galaxy) " );
    }

    public static void RegisterProduct( String jProductID )
    {
        if (jProductID.isEmpty())
        {
            DebugError("RegisterProduct pID is null. (Galaxy) ");
            return;
        }

        if (productIdArr == null)
            productIdArr = new ArrayList<>();

        if (productIdArr.contains(jProductID))
            return;

        GetInstance().productIdArr.add(jProductID);
        Debug( "RegisterProduct pID : " +jProductID + "productIdArr.size() : " + productIdArr.size());
    }

    public static void RefreshProductInfo( final long userCB )
    {
        if ( !CheckInitlized( userCB ) ) return;

        final int inputProductsCount = productIdArr.size();
        String              mConsumablePurchaseIDs = "";
        Intent intent = mMainActivity.getIntent();
        String mProductIds = "";

        final JSONArray productsJsonArray = new JSONArray();
        final ArrayList<String> invalidProductsId = productIdArr;

        if ( intent != null &&
                intent.getExtras() != null &&
                intent.getExtras().containsKey( "ProductIds" ))
        {
            Bundle extras = intent.getExtras();
            mProductIds    = extras.getString( "ProductIds" );
        }

        mIapHelper.getProductsDetails(mProductIds, new OnGetProductsDetailsListener() {
            @Override
            public void onGetProducts(ErrorVo errorVo, ArrayList<ProductVo> arrayList)
            {
                result_status = "UNKNOWN";
                int resultCode = 0;
                String resultMsg;
                if( errorVo != null)
                {
                    if (errorVo.getErrorCode() == IapHelper.IAP_ERROR_NONE)
                    {
                        if (arrayList != null)
                        {
                            Debug("getProductsDetails arrayList.size(): " + arrayList.size());
                            for (int i = 0; i < arrayList.size(); i++)
                            {
                                ProductVo product = arrayList.get(i);
                                Debug("getItemId : " + product.getItemId() + " getCurrencyCode : " + product.getCurrencyCode() + " getIsConsumable : " + product.getIsConsumable() + "getItemPrice : " + product.getItemPrice() );
                                try {
                                    productsJsonArray.put(new JSONObject()
                                            .put("productId", product.getItemId() )
                                            .put("title", product.getItemName() )
                                            .put("description", product.getItemDesc() )
                                            .put("price", product.getItemPrice().toString() )
                                            .put("microPrice", product.getItemPrice() * 1000000)
                                            .put("currencyCode", product.getCurrencyCode())
                                    );
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    result_msg = e.getMessage();
                                }

                                if ( invalidProductsId.contains( product.getItemId() ) )
                                {
                                    invalidProductsId.remove( product.getItemId() );
                                }
                            }

                            if ( productsJsonArray.length() != inputProductsCount )
                            {
                                resultMsg = "Invalid ProductID List => " + invalidProductsId.toString();
                            }
                            else
                            {
                                result_status = "NT_SUCCESS";
                                resultMsg = "RefreshProductInfo() Success";
                                resultCode = 0;
                            }
                            GetInstance().Invoke( result_status, productsJsonArray, resultMsg, resultCode , userCB );
                        }
                    }
                    else
                    {
                        //-1007 Item Not Setting Real
                        //-1002 UNKNOWN
                        if (errorVo.getErrorCode() == IapHelper.IAP_ERROR_ALREADY_PURCHASED)
                        {
                            result_status = "ITEM_ALREADY_OWNED";
                            resultMsg = "The user already owns this item";
                        }
                        else
                        {
                            resultMsg = errorVo.getErrorDetailsString();
                        }
                        resultCode = errorVo.getErrorCode();
                        GetInstance().Invoke( result_status, productsJsonArray, resultMsg, resultCode , userCB );
                    }
                }
                else
                {
                    resultMsg = "RefreshProductInfo() errorVo is null.";
                    DebugError("errorVo.getErrorCode() : " + errorVo.getErrorCode());
                    DebugError("errorVo.getErrorDetailsString() : " + errorVo.getErrorDetailsString());
                    DebugError(resultMsg);
                    GetInstance().Invoke( result_status, productsJsonArray, resultMsg, resultCode , userCB );
                }
            }
        });
    }

    public static void BuyProduct( String jProductID, String jDeveloperPayload, long lUserCB )
    {
        Debug("BuyProduct productID : " + jProductID + " DeveloperPayload : " + jDeveloperPayload );
        final String productID = jProductID;
        final String developerPayload = jDeveloperPayload;
        final long userCB = lUserCB;
        result_msg = "";
        if ( !CheckInitlized( userCB ) ) return;

        if ( productID.isEmpty() ) {
            result_msg = "BuyProduct() productID is null. (Galaxy) ";
            DebugError(result_msg);
            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
            return;
        }
        purchaseCB = userCB;
        mMainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mProductsJsonArray = new JSONArray();
                mIapHelper.startPayment(productID, developerPayload, new OnPaymentListener()
                {
                    @Override
                    public void onPayment(ErrorVo _errorVo, PurchaseVo _purchaseVo) {
                        if (_errorVo != null)
                        {
                            Debug("_errorVo.getErrorString())" + _errorVo.getErrorString());
                            Debug("_errorVo.getErrorCode())" + _errorVo.getErrorCode());
                            if (_errorVo.getErrorCode() == IapHelper.IAP_ERROR_NONE)
                            {
                                if (_purchaseVo != null)
                                {
                                    if (developerPayload != null && _purchaseVo.getPassThroughParam() != null)
                                    {
                                        if (developerPayload.equals(_purchaseVo.getPassThroughParam()))
                                        {
                                            PurchaseVo product = _purchaseVo;
                                            try {

                                                JSONObject pObj = new JSONObject(product.getJsonString());
                                                Debug("pObj : " + pObj.toString());
                                                mProductsJsonArray.put(new JSONObject()
                                                        .put("productId", pObj.getString("mItemId"))
                                                        .put("microPrice", product.getItemPrice() * 1000000 )
                                                        .put("currencyCode", product.getCurrencyCode() )
                                                        .put("originalJson", product.getJsonString() )
                                                        .put("developerPayload", jDeveloperPayload )
                                                        .put("signature", "GalaxySignature" )
                                                        .put(PURCHASEID, product.getPurchaseId() )
                                                        .put("PaymentID", product.getPaymentId() )
                                                );
                                            }
                                            catch (Exception e)
                                            {
                                                e.printStackTrace();
                                                DebugError(e.toString());
                                                result_msg = e.toString();
                                            }

                                            if (_purchaseVo.getIsConsumable())
                                            {
                                                Debug("BuyProduct ItemId : " + _purchaseVo.getItemId() + " PurchaseId : "  + _purchaseVo.getPurchaseId());
                                                mConsumedItemId = _purchaseVo.getPurchaseId();
                                                result_status = "NT_SUCCESS";
                                            }
                                            else
                                            {
                                                result_msg = "NonConsumeAble Item : " + _purchaseVo.getItemId();
                                                DebugError(result_msg);
                                                result_status = "UNKNOWN";
                                            }
                                        } else
                                            DebugError("BuyPurchase passThroughParam is mismatched developerPayload : " + developerPayload +  "_purchaseVo.getPassThroughParam() : " + _purchaseVo.getPassThroughParam());
                                    }
                                }
                                else
                                    DebugError("BuyPurchase > _purchaseVo is null");
                            }
                            else if (_errorVo.getErrorCode() == IapHelper.IAP_PAYMENT_IS_CANCELED)
                            {
                                result_msg = "User canceled the purchase.";
                                Debug(result_msg);
                                result_status = "USER_CANCELED";
                            }
                            else if (_errorVo.getErrorCode() == IapHelper.IAP_ERROR_COMMON)
                            {
                                result_msg = "Item Already owned. :" + jProductID;
                                Debug(result_msg);
                                result_status = "ITEM_ALREADY_OWNED";
                            }
//                            else if (_errorVo.getErrorCode() == IapHelper.IAP_ERROR_NEED_APP_UPGRADE)
//                            {
//                                result_msg = "Need App Upgrade";
//                                Debug(result_msg);
//                                result_status = "NE_PURCHASE_UPDATE_GOOGLEPLAY";
//                            }
                            else
                            {
                                DebugError("BuyPurchase > ErrorCode [" + _errorVo.getErrorCode() + "]");
                                result_msg = "BuyPurchase > ErrorString[" + _errorVo.getErrorString() + "]";
                                DebugError(result_msg);
                            }
                        }
                        result_ResponseCode = _errorVo.getErrorCode();
                        GetInstance().Invoke( result_status, mProductsJsonArray, result_msg, result_ResponseCode , userCB );
                    }
                });
            }
        });
    }

    public static void Consume( final String productID, final long userCB ) throws JSONException {
        Debug( "Consume() productID : " + productID );
        if ( !CheckInitlized( userCB ) ) return;

        result_status = "UNKNOWN";

        String jConsumePurchaseId = null;

        if (mProductsJsonArray == null)
        {
            result_msg = "mProductsJsonArray is null.";
            DebugError(result_msg);
            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
            return;
        }

        for (int i = 0; i < mProductsJsonArray.length(); i++) {
            JSONObject jPurhcaseInfo = mProductsJsonArray.getJSONObject(i);
            if (jPurhcaseInfo.getString("productId").equals(productID))
            {
                Debug("jPurhcaseInfo = " + jPurhcaseInfo.toString());
                String jObjStr = jPurhcaseInfo.getString("originalJson");
                Debug("jObjStr = " + jObjStr);
                JSONObject pJson = new JSONObject(jObjStr);
                jConsumePurchaseId = pJson.getString("mPurchaseId");
                Debug("jConsumePurchaseId = " + jConsumePurchaseId);
                break;
            }
        }
        Debug("jConsumePurchaseId = " + jConsumePurchaseId);

        if ( jConsumePurchaseId != null && !jConsumePurchaseId.isEmpty() )
        {
            Debug("mProductsJsonArray length : " + mProductsJsonArray.length());
            mIapHelper.consumePurchasedItems(jConsumePurchaseId, new OnConsumePurchasedItemsListener()
            {
                @Override
                public void onConsumePurchasedItems(ErrorVo _errorVo, ArrayList<ConsumeVo> _consumeList) {
                    if (_errorVo != null)
                    {
                        if (_errorVo.getErrorCode() == IapHelper.IAP_ERROR_NONE)
                        {
                            try {
                                if (_consumeList != null)
                                {
                                    Debug("Consume _consumeList size() : " + _consumeList.size() );
                                    for (ConsumeVo consumeVo : _consumeList)
                                    {
                                        if (consumeVo.getStatusCode() == 0)
                                        {
                                            Debug("Consume Success :" + consumeVo.getPurchaseId());
                                            result_status = "NT_SUCCESS";
                                            result_msg = "Consume Success : " + productID + " (" + mConsumedItemId + ")";
                                            mProductsJsonArray = new JSONArray();
                                            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
                                            return;
                                        }
                                    }
                                }
                            } catch (Exception e)
                            {
                                DebugError("onConsumePurchasedItems: Exception " + e);
                            }
                        } else {
                            DebugError("onConsumePurchasedItems > ErrorCode [" + _errorVo.getErrorCode() + "]");
                            if (_errorVo.getErrorString() != null)
                                DebugError("onConsumePurchasedItems > ErrorString[" + _errorVo.getErrorString() + "]");
                        }
                        result_msg = _errorVo.getErrorString();
                        result_ResponseCode = _errorVo.getErrorCode();
                    }
                    GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
                }
            });
        }
        else
        {
            result_msg = "Consume Pid is null. : " + productID;
            DebugError(result_msg);
            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
        }
    }

    public static void RestoreProduct( long userCB )
    {
        Debug( "RestoreProduct() start (Galaxy) " );
        if ( !CheckInitlized( userCB ) ) return;
        final JSONArray productsJsonArray = new JSONArray();

        mIapHelper.getOwnedList("item", new OnGetOwnedListListener(){
            @Override
            public void onGetOwnedProducts(ErrorVo _errorVo, ArrayList<OwnedProductVo> _ownedList) {

                Debug("RestoreProduct");
                mProductsJsonArray = new JSONArray();
                if( _errorVo != null) {
                    if (_errorVo.getErrorCode() == IapHelper.IAP_ERROR_NONE)
                    {
                        if (_ownedList != null)
                        {
                            Debug("RestoreProduct size(): "+_ownedList.size());
                            for (int i = 0; i < _ownedList.size(); i++) {
                                OwnedProductVo product = _ownedList.get(i);
                                try {
                                    String oriJson = product.getJsonString();
                                    JSONObject pJson = new JSONObject(oriJson);
                                    Debug("pJson : " + pJson.toString());

                                    mProductsJsonArray.put(new JSONObject()
                                            .put("productId", pJson.getString("mItemId")  )
                                            .put("microPrice", product.getItemPrice() * 1000000)
                                            .put("currencyCode", product.getCurrencyCode() )
                                            .put("originalJson", product.getJsonString()  )
                                            .put("developerPayload", product.getPassThroughParam() )
                                            .put("signature", product.getJsonString() )
                                            .put(PURCHASEID, product.getPurchaseId() )
                                            .put("PaymentID", product.getPaymentId() )
                                    );
                                }
                                catch (Exception e)
                                {
                                    e.printStackTrace();
                                    DebugError(e.toString());
                                }
                                Log.d(LOG_TAG,"pid : " + product.getPaymentId());
                            }
                        }
                    }
                    else
                    {
                        Log.e(LOG_TAG, "onGetOwnedProducts ErrorCode [" + _errorVo.getErrorCode() +"]");
                        if(_errorVo.getErrorString()!=null)
                            Log.e(LOG_TAG, "onGetOwnedProducts ErrorString[" + _errorVo.getErrorString() + "]");
                    }
                }
                else
                    DebugError("getErrorString() : " + _errorVo.getErrorString());

                result_status = "NT_SUCCESS";
                result_msg = _errorVo.getErrorString();
                result_ResponseCode = _errorVo.getErrorCode();
                GetInstance().Invoke( result_status, mProductsJsonArray, result_msg, result_ResponseCode , userCB );
            }
        });
    }

    public static void ConsumeAll( long userCB ) throws JSONException {
        Debug( "ConsumeAll() (Galaxy) " );

        if ( !CheckInitlized( userCB ) ) return;
        mIapHelper.getOwnedList("item", new OnGetOwnedListListener(){
            @Override
            public void onGetOwnedProducts(ErrorVo _errorVo, ArrayList<OwnedProductVo> _ownedList)
            {
                mProductsJsonArray = new JSONArray();
                if( _errorVo != null)
                {
                    if (_errorVo.getErrorCode() == IapHelper.IAP_ERROR_NONE)
                    {
                        int gunLevel = 0;
                        boolean infiniteBullet = false;
                        if (_ownedList != null)
                        {
                            Debug("ConsumeAll size(): " + _ownedList.size());
                            for (int i = 0; i < _ownedList.size(); i++)
                            {
                                OwnedProductVo product = _ownedList.get(i);
                                Debug("purchaseId : " + product.getPurchaseId());
                                String jPurchaseId = product.getPurchaseId();
                                mIapHelper.consumePurchasedItems(jPurchaseId, new OnConsumePurchasedItemsListener()
                                {
                                    @Override
                                    public void onConsumePurchasedItems(ErrorVo _errorVo, ArrayList<ConsumeVo> _consumeList) {
                                        if (_errorVo != null)
                                        {
                                            if (_errorVo.getErrorCode() == IapHelper.IAP_ERROR_NONE)
                                            {
                                                try {
                                                    if (_consumeList != null)
                                                    {
                                                        for (ConsumeVo consumeVo : _consumeList)
                                                        {
                                                            if (consumeVo.getStatusCode() == 0)
                                                                Debug("ConsumeAll Consume Success : " + consumeVo.getPurchaseId() );
                                                            else
                                                                DebugError("ConsumeAll : getJsonString " + consumeVo.getJsonString());
                                                        }
                                                    }
                                                } catch (Exception e)
                                                {
                                                    DebugError("ConsumeAll : Exception " + e);
                                                }
                                            } else {
                                                DebugError("ConsumeAll  > ErrorCode [" + _errorVo.getErrorCode() + "]");
                                                if (_errorVo.getErrorString() != null)
                                                    DebugError("ConsumeAll  > ErrorString[" + _errorVo.getErrorString() + "]");
                                            }
                                        }
                                        mConsumedItemId = "";
                                    }
                                });
                            }
                        }
                    }
                    else
                        Log.e(LOG_TAG, "ConsumeAll onGetOwnedProducts ErrorCode [" + _errorVo.getErrorCode() +"]");
                }
                else
                    DebugError("ConsumeAll getErrorString() : " + _errorVo.getErrorString());
            }
        });
    }

    private void Invoke( String result_status, JSONArray productJsonArr, String msg, int resultCode, long userCB )
    {
        final JSONObject jsonResult = new JSONObject();
        try
        {
            jsonResult.put( "products", productJsonArr );
            jsonResult.put( "Message", msg );
            jsonResult.put( "ResponseCode", resultCode);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            result_msg = e.getMessage();
            DebugError(result_msg);
        }

        if (userCB != noCB)
        {
            Debug( "Invoke() status : " + result_status + " msg : " + jsonResult.toString() + " userCB : " + userCB  );
            nativeCB( result_status, jsonResult.toString(), userCB );
        }
    }

    private static boolean CheckInitlized( long userCB )
    {
        if ( mMainActivity == null )
            mMainActivity = NTBase.getMainActivity();

        result_status = "UNKNOWN";
        result_ResponseCode = -1;

        if ( !IsConnected() )
        {
            result_msg = "Purchase is not ready. First Call Connect() API. (Galaxy) ";
            DebugError(result_msg);
            GetInstance().Invoke( result_status, new JSONArray(), result_msg, result_ResponseCode , userCB );
            return false;
        }
        return true;
    }

    private static boolean IsConnected()
    {
        if (mIapHelper == null)
            return false;
        else
            return true;
    }

    public void OnResume()
    {
        Debug("NTSDK OnResume (Galaxy) ");
        if ( mMainActivity != null )
        {
            Connect( noCB );
        }
    }

    //=======================================//    Log    //========================================//
    private static void Debug( String logMessage )
    {
        GetInstance().LogLineDebug( "[" + PURCHASE_TAG + "]: " + logMessage );
    }

    private void LogLineDebug(String str) {

        int limitedline = 3000;
        String temp_json = str;
        int log_index = 1;
        try {
            while (temp_json.length() > 0) {

                if (temp_json.length() > limitedline) {
                    Log.d(LOG_TAG, "log - " + log_index + " : "
                            + temp_json.substring(0, limitedline));
                    temp_json = temp_json.substring(limitedline);
                    log_index++;
                } else {
                    Log.d(LOG_TAG, temp_json);
                    break;
                }
            }
        } catch (Exception e)
        {
            e.printStackTrace();
            DebugError(result_msg);
        }
    }

    private static void DebugError( String logMessage )
    {
        Log.e( LOG_TAG, "[" + PURCHASE_TAG + "]: " + logMessage );
    }
    //========================================//    Log    //=========================================//

    public void OnStop()
    {
    }

    public void OnDestory()
    {
        mIapHelper.dispose();
    }
}